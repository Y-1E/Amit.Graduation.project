/*
 * Final_Project.c
 *
 * Created: 23/03/2021 03:17:08 ص
 * Author : Elmohandz Yehia
 */ 


//main for master 


#include "UART.h"
#include "SPI.h"
volatile Uint8t data;
//volatile Uint8t value;

int main(void)
{
	UART_Init();
	SPI_Init();
	SPI_SlaveSelect(0);
	sei();
	message();
    while (1) 
    {
		SPI_Transmit(data);
    }
}

ISR (USART_RXC_vect)
{
	data = UDR;
	UART_Transmit(data);
}
ISR(SPI_STC_vect)
{
	SPDR=data;
}
