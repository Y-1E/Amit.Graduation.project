


#include "UART.h"


void UART_Init(void)
{
	/*Baud rate value variable*/
	Uint16t UBRR_Val = 0;
	/*Enable Transmitter and Receiver bits*/
	UCSRB = (1 << RXEN) | (1 << TXEN) | (1<<RXCIE);
	/*Full configuration for UART*/
	UCSRC = (1 << URSEL) | (1 << UCSZ1) | (1 << UCSZ0);
	/*Baud Rate Calculations*/
	UBRR_Val = (((FRQ) / (16 * BAUDRATE)) - 1);//00000000 11110101 00111001
	UBRRL = UBRR_Val;//00111001
	UBRRH = UBRR_Val >> 8;//11110101
}
void UART_Transmit(Uint8t data)
{
	UDR = data;
	while (GET_BIT(UCSRA, TXC) != 1);
}
Uint8t UART_Receive(void)
{
	while (GET_BIT(UCSRA, TXC) != 1);
	return UDR;
}
void UART_Tstr(char *str)/*write string on screen*/
{
	while(*str)
	{
		UART_Transmit(*(str++));
		//str++;
		_delay_ms(1);
	}
}
void message(void)
{
	UART_Tstr("Please Enter 'a' to led one turn on : \r\n");
	UART_Tstr("Please Enter 'b' to led two turn on : \r\n");
	UART_Tstr("Please Enter 'c' to led 4th turn on : \r\n");
	UART_Tstr("Please Enter 's' to all led turn of : \r\n");
}


