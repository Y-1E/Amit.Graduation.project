/*
 * FinalProject_PART2.c
 *
 * Created: 23/03/2021 06:28:29 م
 * Author : Elmohandz Yehia
 */ 

//#include "UART.h"
#include "SPI.h"
#include "LED.h"
volatile Uint8t data;


int main(void)
{
	SPI_Init();
	LED0_Init();
	LED1_Init();
	LED2_Init();
	//sei();
	while(1)
	{
		_delay_ms(10);
	}


}

ISR(SPI_STC_vect)
{
	data=SPDR;
	if (data=='a')
	{
		LED0_ON();
	}
	else if (data=='b')
	{
		LED1_ON();
	}
	else if (data=='c')
	{
		LED2_ON();
	}
	else if (data=='s')
	{
		LED2_OFF();
		LED1_OFF();
		LED0_OFF();
	}
}
